<?php

class User_model extends CI_model {

    public function login_user($email, $password) {
        $this->db->where('email', $email);
        $result = $this->db->get('user');
        if ($result->num_rows()) {
            $db_password = $result->row(1)->password;

           
            if ($password == $db_password) {

                return $result->row(1);
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}